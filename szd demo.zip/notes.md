# dpmsign credentials

server username: dpmswgtf
server password: 5UdqGnt9v568%$#W22##45
server ip: 199.188.205.37
server port: 21098

db user: dpmswgtf_user
db user password: dpmsign@54321
db name: dpmswgtf_db

# TODO

- [x] search box
- [x] Base price should be named -> Unit price
- [x] Additional price should be named -> Base price
- [x] Send order request button add
- [x] Remove price chart and also the full tab from individual product page
- [x] product show algorithm randomly
- [x] Customer order tracking ui fix
- [x] create a payment success page in frontend and redirect to the the payment success page in frontend
- [x] privacy policy and terms and condition bangla version

- [ ] product review without login (problem)
- [ ] checkout page auto account creation if not have (problem)

- [ ] fix staff/courier route get method authentication function
- [ ] category filtering fix
- [ ] view invoices fix

- [x] newsletter export (admin dashboard)
- [x] Requested order should be named -> New Request (admin dashboard)
- [x] Product SKU searching (admin dashboard)
- [x] product variation edit fix (admin dashboard)
- [x] order export csv, excel (admin dashboard)
- [x] order module (admin dashboard)
- [x] order fetching type added for active, requested, completed (admin dashboard)
- [x] Add Job open/close status (admin dashboard)
- [x] define a cron job to remove payments link that are not valid anymore every 24 hours
- [x] Unlisted product add (admin dashboard)
- [x] Order status change logic update (admin dashboard)
- [x] online order can't pay via cod (admin dashboard)
- [x] Staff delete method (admin dashboard) [add a isDelete prop in the staff model]

- [ ] Dashboard stats fix (admin dashboard)
- [ ] Agents personal earning reports, balances (admin dashboard)

- [ ] online/offline both orders can pay via online (admin dashboard)
- [ ] Use bulk delete for all modules (admin dashboard)
